#ifndef MESSAGEMANAGER_H

#define MESSAGEMANAGER_H

#include "json.hpp"
#include <unordered_map>
#include <vector>

enum Mess_Type
{
    ONE_CHAT_TYPE,
    GROUP_CHAT_TYPE,
};


class MessageManager
{
public:
    MessageManager(const MessageManager&) = delete;
    MessageManager(const MessageManager&& ) = delete;
    MessageManager& operator=(const MessageManager&) = delete;

    static MessageManager& GetInstance();

    ~MessageManager();

    void addMessage(Mess_Type type ,unsigned int id, const std::string& message);

    std::vector<std::string> getMessages(Mess_Type type, unsigned int id);

    void load();

    void clear();

private:
    MessageManager();

private:
    std::unordered_map<unsigned int, std::vector<std::string>> _user_mess_map;
    std::unordered_map<unsigned int, std::vector<std::string>> _group_mess_map;
    nlohmann::json _user_mess_json;
    nlohmann::json _group_mess_json;
    std::fstream* _user_mess_file;
    std::fstream* _group_mess_file;
};

#endif // MESSAGEMANAGER_H
