#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include "loginwinow.h"
#include "settingwindow.h"
#include "userinfoedit.h"
#include <atomic>
#include "custemlistitem.h"
#include <QListWidget>
#include "chatitem.h"
#include "messagemanager.h"
#include <unordered_map>
#include "addwidget.h"
#include "creategroupwidget.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

enum LIST_WIDGET {
    USER_LIST_WIDGET = 0,
    GROUP_CHAT_LIST_WIDGET = 3,
    SEARCH_LIST_WIDGET = 1,
    MESSAGE_LIST_WIDGET = 2,
};

struct MessageInfo
{
    CHAT_TYPE chat_type;
    unsigned int id;
};

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    // 重写窗口移动事件
    void moveEvent(QMoveEvent* event) override;
    // 重写鼠标点击事件
    void mousePressEvent(QMouseEvent* event) override;
    // 重写窗口状态改变事件
    void changeEvent(QEvent* event) override;
    // 重写窗口关闭事件
    void closeEvent(QCloseEvent* event) override;

private:
    // 持续监听来自服务器的消息
    void continued_listen_message();

    QListWidgetItem* add_left_list_widget_item(QListWidget* target_widget ,const QString& chat_name, const QString& chat_message, QWidget *parent = nullptr, int chat_type = SINGLE_CHAT, bool flag = true);

    QListWidgetItem* insert_left_list_widget_top_item(QListWidget* target_widget ,const QString& chat_name, const QString& chat_message, QWidget *parent = nullptr, int chat_type = SINGLE_CHAT, bool flag = true);

    void delete_list_widget_item(QListWidget* target_widget, QListWidgetItem* target_item);

    void clear_left_list_widget(QListWidget* target_widget);

    void clear_right_list_widget();

    void init_search_lineedit();

    void init_message_input_textedit();

    void init_toolButton();

    void init_friends_list();

    void init_group_list();

    void init_gif();

    void init_add_toolButton_menu();

    // 登录槽函数
    void slot_login_in();

    void slot_mess_toolButton_click();

    void slot_friends_toolButton_click();

    void slot_gc_toolButton_click();

    // 设置按钮的槽函数
    void slot_setting_toolButton_click();

    // 登出（发送登出消息+关闭本地socket连接）
    void slot_login_out();

    void slot_send_pushButton_click();

    void slot_user_list_widget_item_clicked(QListWidgetItem* item);

    void slot_group_list_widget_item_clicked(QListWidgetItem* item);

    void slot_message_list_widget_item_clicked(QListWidgetItem* item);

    void slot_search_list_widget_item_clicked(QListWidgetItem* item);

    void slot_new_message_add_item(std::string msg);

    void slot_new_message_remind(std::string msg);

    void slot_search_lineedit_enter_press();

    void slot_add_menu_add_friend();

    void slot_add_menu_add_group_chat();

    void slot_addwidget_close();

    void slot_added_group();

    void slot_added_user();

    void slot_create_group();

    void slot_create_group_widget_close();

signals:
    void signal_new_message_add_item(std::string msg);
    void signal_new_message_remind(std::string msg);
    void signal_added_refresh_user_list();

private:
    Ui::MainWindow *ui;
    std::atomic_bool _is_listening;     //是否持续监听
    LoginWinow _login_window;           // 登录窗口
    SettingWindow _setting_window;      // 设置窗口
    UserInfoEdit _user_info_edit;       // 用户信息修改窗口
    std::unordered_map<QListWidgetItem* , unsigned int> _item_userid_map;   // 通过item寻找useid
    std::unordered_map<QListWidgetItem* , unsigned int> _item_groupid_map;  // 通过item寻找groupid
    std::unordered_map<QListWidgetItem* , MessageInfo>  _item_message_map;      // 通过item寻找这个message的详细信息
    std::unordered_map<QListWidgetItem* , MessageInfo> _item_search_map;
    CHAT_TYPE _chat_type;
    unsigned int _userid;
    AddWidget* _addwidget;
    CreateGroupWidget* _create_group_widget;
};
#endif // MAINWINDOW_H
