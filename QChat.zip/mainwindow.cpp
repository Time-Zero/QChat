#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPushButton>
#include <QFile>
#include "localuser.h"
#include <QWindowStateChangeEvent>
#include "json.hpp"
#include "public.h"
#include "qchatsocket.h"
#include "custemlistitem.h"
#include "textbubble.h"
#include <thread>
#include "messagemanager.h"
#include <QMovie>
#include <QMenu>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWindow),
    _setting_window(nullptr),
    _is_listening(false),
    _chat_type(SINGLE_CHAT),
    _userid(0),
    _addwidget(nullptr),
    _create_group_widget(nullptr)
{
    ui->setupUi(this);
    this->resize(QSize(960,640));
    this->setWindowTitle("QChat");

    QFile file(":/mainwindow/mainwindow.qss");
    if(file.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream qfilestream(&file);
        QString style_str = qfilestream.readAll();
        this->setStyleSheet(style_str);
        file.close();
    }

    ui->ps_widget->setMaximumWidth(250);
    ui->func_widget->setMaximumWidth(60);
    ui->search_lineEdit->setPlaceholderText("搜索");
    init_search_lineedit();
    init_toolButton();
    init_message_input_textedit();
    init_gif();
    init_add_toolButton_menu();

    // 登录成功后显示主窗口,并且开启消息监听线程持续监听报文
    connect(&_login_window ,&LoginWinow::signal_login,this,&MainWindow::slot_login_in);
    connect(ui->send_pushButton, &QPushButton::clicked, this, &MainWindow::slot_send_pushButton_click);
    connect(ui->user_list_listWidget,&QListWidget::itemClicked,this, &MainWindow::slot_user_list_widget_item_clicked);
    connect(ui->group_chat_listWidget, &QListWidget::itemClicked,this,&MainWindow::slot_group_list_widget_item_clicked);
    connect(this, &MainWindow::signal_new_message_add_item,this,&MainWindow::slot_new_message_add_item);
    connect(this,&MainWindow::signal_new_message_remind,this, &MainWindow::slot_new_message_remind);
    connect(ui->message_listWidget, &QListWidget::itemClicked,this,&MainWindow::slot_message_list_widget_item_clicked);
    connect(ui->search_lineEdit, &QLineEdit::returnPressed,this,&MainWindow::slot_search_lineedit_enter_press);
    connect(ui->search_listWidget,&QListWidget::itemClicked,this, &MainWindow::slot_search_list_widget_item_clicked);
    // 修改用户信息
    connect(&_setting_window,&SettingWindow::EditUserInfo,this,[&](){
        _user_info_edit.SetId(LocalUser::GetInstance().GetId());
        _user_info_edit.SetName(LocalUser::GetInstance().GetName());
        _user_info_edit.show();
    });
    // 退出登录按钮
    connect(&_setting_window,&SettingWindow::LoginOut,this,[&](){
        slot_login_out();
        // 窗口显示和隐藏操作
        this->hide();
        _login_window.show();
    });

    connect(this,&MainWindow::signal_added_refresh_user_list,this,[&](){
        clear_left_list_widget(ui->user_list_listWidget);
        init_friends_list();
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}


/**
 * @brief MainWindow::moveEvent
 * 主窗口移动事件
 * @param event
 */
void MainWindow::moveEvent(QMoveEvent *event)
{
    // 如果设置窗口打开，则让设置窗口跟随主窗口移动
    if(_setting_window.isVisible())
    {
        QPoint func_widget_global_pos = ui->func_widget->mapToGlobal(QPoint(0,0));
        int func_widget_height = ui->func_widget->height();
        int func_widget_width = ui->func_widget->width();
        int setting_widow_height = _setting_window.height();
        _setting_window.move(func_widget_global_pos.x() + func_widget_width + 5, func_widget_global_pos.y() + func_widget_height - setting_widow_height - 5);
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    // 如果设置窗口打开时，点击其他位置，则关闭设置窗口
    if(_setting_window.isVisible())
    {
        _setting_window.hide();
    }
}

void MainWindow::changeEvent(QEvent *event)
{
    if(event->type() == QEvent::WindowStateChange)
    {
        // QWindowStateChangeEvent* state_event = static_cast<QWindowStateChangeEvent*>(event);
        if(this->windowState() == Qt::WindowMinimized)
        {
            _setting_window.hide();
        }
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    slot_login_out();
}


void MainWindow::init_search_lineedit()
{
    QAction* search_action = new QAction(ui->search_lineEdit);
    search_action->setIcon(QIcon(":/mainwindow/pictures/search.png"));
    ui->search_lineEdit->addAction(search_action, QLineEdit::LeadingPosition);
}

void MainWindow::init_message_input_textedit()
{
    QFont font("Microsoft YaHei",12);
    ui->message_input_textEdit->setFont(font);
}

void MainWindow::init_toolButton()
{
    int height = ui->search_lineEdit->size().height();

    QPixmap mess_pixmap(":/mainwindow/pictures/message.png");
    ui->mess_toolButton->setIcon(QIcon(mess_pixmap));
    ui->mess_toolButton->setFixedSize(height,height);
    ui->mess_toolButton->setCheckable(true);
    ui->mess_toolButton->setChecked(true);
    connect(ui->mess_toolButton, &QToolButton::clicked,this,&MainWindow::slot_mess_toolButton_click);

    QPixmap friend_pixmap(":/mainwindow/pictures/friend.png");
    ui->friends_toolButton->setIcon(QIcon(friend_pixmap));
    ui->friends_toolButton->setFixedSize(height,height);
    ui->friends_toolButton->setCheckable(true);
    connect(ui->friends_toolButton, &QToolButton::clicked,this,&MainWindow::slot_friends_toolButton_click);


    QPixmap group_pixmap(":/mainwindow/pictures/group.png");
    ui->gc_toolButton->setIcon(QIcon(group_pixmap));
    ui->gc_toolButton->setFixedSize(height,height);
    ui->gc_toolButton->setCheckable(true);
    connect(ui->gc_toolButton, &QToolButton::clicked,this,&MainWindow::slot_gc_toolButton_click);


    QPixmap setting_pixmap(":/mainwindow/pictures/setting.png");
    ui->setting_toolButton->setIcon(QIcon(setting_pixmap));
    ui->setting_toolButton->setFixedSize(height,height);
    ui->setting_toolButton->setCheckable(true);
    connect(ui->setting_toolButton, &QToolButton::clicked,this,&MainWindow::slot_setting_toolButton_click);


    QPixmap add_pixmap(":/mainwindow/pictures/add.png");
    ui->add_toolButton->setIcon(QIcon(add_pixmap));
    ui->add_toolButton->setFixedSize(height,height);
    ui->add_toolButton->setCheckable(true);
    // connect(ui->mess_toolButton, &QToolButton::clicked,this,&MainWindow::slot_mess_toolButton_click);
}

void MainWindow::init_friends_list()
{
    std::vector<User> friends = LocalUser::GetInstance().GetFriends();
    for(User& it : friends)
    {   
        auto p_item = add_left_list_widget_item(ui->user_list_listWidget ,QString::fromStdString(it.GetName()),"",nullptr,SINGLE_CHAT, false);
        _item_userid_map[p_item] = it.GetId();
    }
}

void MainWindow::init_group_list()
{
    std::vector<Group> groups = LocalUser::GetInstance().GetGroups();
    for(Group& it : groups)
    {   
        auto p_item = add_left_list_widget_item(ui->group_chat_listWidget, QString::fromStdString(it.GetName()), QString::fromStdString(it.GetDesc()),nullptr, GROUP_CHAT, false);
        _item_groupid_map[p_item] = it.GetId();
    }
}

void MainWindow::init_gif()
{
    ui->gif_label->setFixedSize(100,100);
    QMovie* gif = new QMovie();
    gif->setFileName(":/login/pictures/rainbow_cat.gif");
    QSize si(ui->gif_label->width(), ui->gif_label->height());
    gif->setScaledSize(si);

    ui->gif_label->setMovie(gif);
    gif->start();
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::init_add_toolButton_menu()
{
    QMenu *menu = new QMenu(this);
    QAction* createGroupAction = new QAction("创建群聊",this);
    connect(createGroupAction,&QAction::triggered,this, &MainWindow::slot_create_group);
    menu->addAction(createGroupAction);

    QAction* addFriendAction = new QAction("添加好友",this);
    connect(addFriendAction,&QAction::triggered,this,&MainWindow::slot_add_menu_add_friend);
    menu->addAction(addFriendAction);

    QAction* addGroupChatAction = new QAction("添加群聊",this);
    connect(addGroupChatAction,&QAction::triggered,this,&MainWindow::slot_add_menu_add_group_chat);
    menu->addAction(addGroupChatAction);

    menu->setWindowFlags(menu->windowFlags() | Qt::FramelessWindowHint);
    // menu->setAttribute(Qt::WA_TranslucentBackground, true);
    ui->add_toolButton->setMenu(menu);
    ui->add_toolButton->setPopupMode(QToolButton::InstantPopup);
    ui->add_toolButton->setStyleSheet("QToolButton::menu-indicator{image:none;}");
}

/**
 * @brief MainWindow::slot_login_in
 * 登录槽函数，会设置监听标志位后开启消息监听线程，最后显示主窗口
 */
void MainWindow::slot_login_in()
{
    MessageManager::GetInstance().load();
    init_friends_list();
    init_group_list();
    ui->list_wiget_stackedWidget->setCurrentIndex(MESSAGE_LIST_WIDGET);
    _is_listening.store(true);
    continued_listen_message();
    this->show();
}

void MainWindow::slot_mess_toolButton_click()
{
    ui->mess_toolButton->setChecked(true);
    ui->friends_toolButton->setChecked(false);
    ui->gc_toolButton->setChecked(false);
    ui->setting_toolButton->setChecked(false);
    ui->list_wiget_stackedWidget->setCurrentIndex(MESSAGE_LIST_WIDGET);
}

void MainWindow::slot_friends_toolButton_click()
{
    ui->mess_toolButton->setChecked(false);
    ui->friends_toolButton->setChecked(true);
    ui->gc_toolButton->setChecked(false);
    ui->setting_toolButton->setChecked(false);
    ui->list_wiget_stackedWidget->setCurrentIndex(USER_LIST_WIDGET);
}

void MainWindow::slot_gc_toolButton_click()
{
    ui->mess_toolButton->setChecked(false);
    ui->friends_toolButton->setChecked(false);
    ui->gc_toolButton->setChecked(true);
    ui->setting_toolButton->setChecked(false);
    ui->list_wiget_stackedWidget->setCurrentIndex(GROUP_CHAT_LIST_WIDGET);
}

/**
 * @brief MainWindow::slot_setting_toolButton_click
 *  设置按钮的槽函数
 */
void MainWindow::slot_setting_toolButton_click()
{
    ui->mess_toolButton->setChecked(false);
    ui->friends_toolButton->setChecked(false);
    ui->gc_toolButton->setChecked(false);
    ui->setting_toolButton->setChecked(true);

    QPoint func_widget_global_pos = ui->func_widget->mapToGlobal(QPoint(0,0));
    int func_widget_height = ui->func_widget->height();
    int func_widget_width = ui->func_widget->width();
    int setting_widow_height = _setting_window.height();
    _setting_window.move(func_widget_global_pos.x() + func_widget_width + 5, func_widget_global_pos.y() + func_widget_height - setting_widow_height - 5);

    if(!_setting_window.isVisible())
    {
        _setting_window.show();
    }
}

/**
 * @brief MainWindow::slot_login_out
 * 登出信号的槽函数
 */
void MainWindow::slot_login_out()
{
    // 向服务器发送登出消息
    nlohmann::json js;
    js["msgid"] = LOGIN_OUT_MSG;
    js["id"] = LocalUser::GetInstance().GetId();
    QChatSocket::GetInstance().Send(js.dump());

    MessageManager::GetInstance().clear();

    // 清除本地登录用户信息
    LocalUser::GetInstance().Reset();

    // 停止持续监听线程的动作
    _is_listening.store(false);

    // 关闭当前socket
    QChatSocket::GetInstance().Close();

    clear_left_list_widget(ui->user_list_listWidget);
    clear_left_list_widget(ui->group_chat_listWidget);
    clear_left_list_widget(ui->message_listWidget);
    clear_left_list_widget(ui->message_show_listWidget);
}

void MainWindow::slot_send_pushButton_click()
{
    QString msg = ui->message_input_textEdit->toPlainText();
    if(msg.length() == 0)
        return;

    int role = Chat_Role::ME;
    QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
    QString user_icon_path = ":/mainwindow/pictures/people.png";

    ChatItem* p_chat_item = new ChatItem(role);
    p_chat_item->setUserName(user_name);
    p_chat_item->setUserIcon(QPixmap(user_icon_path));
    QWidget* p_bubble = new TextBubble(role,msg);

    p_chat_item->setWidget(p_bubble);
    QListWidgetItem* p_item = new QListWidgetItem();

    p_item->setSizeHint(QSize(125,90));
    ui->message_show_listWidget->addItem(p_item);
    ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);

    // 整合报文内容
    nlohmann::json msg_js;
    // 如果是单人聊天
    if(_chat_type == CHAT_TYPE::SINGLE_CHAT)
    {
        msg_js["msgid"] = EnMsgType::ONE_CHAT_MSG;
        msg_js["id"] = LocalUser::GetInstance().GetId();
        msg_js["to"] = _userid;
        msg_js["msg"] = msg.toStdString();
        MessageManager::GetInstance().addMessage(Mess_Type::ONE_CHAT_TYPE, _userid, msg_js.dump());
    }
    // 如果是群聊
    else if(_chat_type == CHAT_TYPE::GROUP_CHAT)
    {
        msg_js["msgid"] = EnMsgType::GROUP_CHAT_MSG;
        msg_js["id"] = LocalUser::GetInstance().GetId();
        msg_js["name"] = LocalUser::GetInstance().GetName();
        msg_js["groupid"] = _userid;
        msg_js["msg"] = msg.toStdString();
        MessageManager::GetInstance().addMessage(Mess_Type::GROUP_CHAT_TYPE, _userid, msg_js.dump());
    }
    //发送报文
    QChatSocket::GetInstance().Send(msg_js.dump());
    ui->message_input_textEdit->clear();
}

void MainWindow::slot_user_list_widget_item_clicked(QListWidgetItem *item)
{
    if(item != nullptr)
    {
        auto it = _item_userid_map.find(item);
        if(it == _item_userid_map.end())
            return;

        if(this->_chat_type == SINGLE_CHAT && this->_userid == it->second)
            return;

        // 清空和上一个人的聊天记录
        clear_right_list_widget();
        this->_chat_type = SINGLE_CHAT;
        this->_userid = it->second;
        std::string chat_name = LocalUser::GetInstance().GetFriendName(this->_userid);
        if(chat_name.empty())
            return;
        ui->chat_people_name_label->setText(QString::fromStdString(chat_name));

        auto history_message = MessageManager::GetInstance().getMessages(Mess_Type::ONE_CHAT_TYPE, this->_userid);
        for(auto message : history_message)
        {
            nlohmann::json msg_js = nlohmann::json::parse(message);
            // 如果是我发的
            if(msg_js["id"] == LocalUser::GetInstance().GetId())
            {
                int role = Chat_Role::ME;
                QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
            else
            {
                int role = Chat_Role::HE;
                QString user_name = ui->chat_people_name_label->text();
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
        }

        if(ui->stackedWidget->currentIndex() != 1)
            ui->stackedWidget->setCurrentIndex(1);
    }
}

void MainWindow::slot_group_list_widget_item_clicked(QListWidgetItem *item)
{
    if(item != nullptr)
    {
        // 插一下这个group的id
        auto it = _item_groupid_map.find(item);
        if(it == _item_groupid_map.end())
            return;

        // 如果聊天窗口就是和我们这个群聊天，直接返回
        if(this->_chat_type == GROUP_CHAT && this->_userid == it->second)
            return;

        // 清空原来的消息item
        clear_right_list_widget();
        // 把群聊窗口的type设置为群聊，并且把_userid设置为这个群的groupid
        this->_chat_type = GROUP_CHAT;
        this->_userid = it->second;
        // 获取一下群聊名字
        std::string chat_name = LocalUser::GetInstance().GetGroupName(this->_userid);
        if(chat_name.empty())
            return;
        ui->chat_people_name_label->setText(QString::fromStdString(chat_name));

        auto history_message = MessageManager::GetInstance().getMessages(Mess_Type::GROUP_CHAT_TYPE, this->_userid);
        for(auto message : history_message)
        {
            nlohmann::json msg_js = nlohmann::json::parse(message);
            // 如果是我发的
            if(msg_js["id"] == LocalUser::GetInstance().GetId())
            {
                int role = Chat_Role::ME;
                QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
            else
            {
                int role = Chat_Role::HE;
                QString user_name = QString::fromStdString(msg_js["name"]);
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
        }

        ui->chat_people_name_label->setText(QString::fromStdString(chat_name));
        if(ui->stackedWidget->currentIndex() != 1)
            ui->stackedWidget->setCurrentIndex(1);
    }
}

void MainWindow::slot_message_list_widget_item_clicked(QListWidgetItem *item)
{
    if(item != nullptr)
    {
        auto it = _item_message_map.find(item);
        if(it == _item_message_map.end())
            return;

        CHAT_TYPE chat_type = it->second.chat_type;
        unsigned int sender_id = it->second.id;

        if(chat_type == this->_chat_type && sender_id == _userid)
            return;

        clear_right_list_widget();
        this->_chat_type = chat_type;
        this->_userid = sender_id;
        QString chat_name;
        if(chat_type == CHAT_TYPE::SINGLE_CHAT)
        {
            chat_name = QString::fromStdString(LocalUser::GetInstance().GetFriendName(sender_id));
            auto history_message = MessageManager::GetInstance().getMessages(Mess_Type::ONE_CHAT_TYPE, this->_userid);
            for(auto message : history_message)
            {
                nlohmann::json msg_js = nlohmann::json::parse(message);
                // 如果是我发的
                if(msg_js["id"] == LocalUser::GetInstance().GetId())
                {
                    int role = Chat_Role::ME;
                    QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
                    QString user_icon_path = ":/mainwindow/pictures/people.png";

                    ChatItem* p_chat_item = new ChatItem(role);
                    p_chat_item->setUserName(user_name);
                    p_chat_item->setUserIcon(QPixmap(user_icon_path));
                    QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                    p_chat_item->setWidget(p_bubble);
                    QListWidgetItem* p_item = new QListWidgetItem();

                    p_item->setSizeHint(QSize(125,90));
                    ui->message_show_listWidget->addItem(p_item);
                    ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
                }
                else
                {
                    int role = Chat_Role::HE;
                    QString user_name = ui->chat_people_name_label->text();
                    QString user_icon_path = ":/mainwindow/pictures/people.png";

                    ChatItem* p_chat_item = new ChatItem(role);
                    p_chat_item->setUserName(user_name);
                    p_chat_item->setUserIcon(QPixmap(user_icon_path));
                    QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                    p_chat_item->setWidget(p_bubble);
                    QListWidgetItem* p_item = new QListWidgetItem();

                    p_item->setSizeHint(QSize(125,90));
                    ui->message_show_listWidget->addItem(p_item);
                    ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
                }
            }
        }
        else
        {
            chat_name = QString::fromStdString(LocalUser::GetInstance().GetGroupName(sender_id));
            auto history_message = MessageManager::GetInstance().getMessages(Mess_Type::GROUP_CHAT_TYPE, this->_userid);
            for(auto message : history_message)
            {
                nlohmann::json msg_js = nlohmann::json::parse(message);
                // 如果是我发的
                if(msg_js["id"] == LocalUser::GetInstance().GetId())
                {
                    int role = Chat_Role::ME;
                    QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
                    QString user_icon_path = ":/mainwindow/pictures/people.png";

                    ChatItem* p_chat_item = new ChatItem(role);
                    p_chat_item->setUserName(user_name);
                    p_chat_item->setUserIcon(QPixmap(user_icon_path));
                    QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                    p_chat_item->setWidget(p_bubble);
                    QListWidgetItem* p_item = new QListWidgetItem();

                    p_item->setSizeHint(QSize(125,90));
                    ui->message_show_listWidget->addItem(p_item);
                    ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
                }
                else
                {
                    int role = Chat_Role::HE;
                    QString user_name = QString::fromStdString(msg_js["name"]);
                    QString user_icon_path = ":/mainwindow/pictures/people.png";

                    ChatItem* p_chat_item = new ChatItem(role);
                    p_chat_item->setUserName(user_name);
                    p_chat_item->setUserIcon(QPixmap(user_icon_path));
                    QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                    p_chat_item->setWidget(p_bubble);
                    QListWidgetItem* p_item = new QListWidgetItem();

                    p_item->setSizeHint(QSize(125,90));
                    ui->message_show_listWidget->addItem(p_item);
                    ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
                }
            }
        }
        ui->chat_people_name_label->setText(chat_name);
        if(ui->stackedWidget->currentIndex() != 1)
            ui->stackedWidget->setCurrentIndex(1);

        auto widget = static_cast<CustemListItem*>(ui->message_listWidget->itemWidget(item));
        widget->show_red_point(false);
    }
}

void MainWindow::slot_search_list_widget_item_clicked(QListWidgetItem *item)
{
    auto it = _item_search_map.find(item);
    if(it == _item_search_map.end())
        return;

    clear_right_list_widget();
    MessageInfo message_info = it->second;
    this->_chat_type = message_info.chat_type;
    this->_userid = message_info.id;
    QString chat_name;
    if(message_info.chat_type == CHAT_TYPE::SINGLE_CHAT)
    {
        chat_name = QString::fromStdString(LocalUser::GetInstance().GetFriendName(message_info.id));
    }
    else
    {
        chat_name = QString::fromStdString(LocalUser::GetInstance().GetGroupName(message_info.id));
    }


    if(message_info.chat_type == CHAT_TYPE::SINGLE_CHAT)
    {
        auto history_message = MessageManager::GetInstance().getMessages(Mess_Type::ONE_CHAT_TYPE, this->_userid);
        for(auto message : history_message)
        {
            nlohmann::json msg_js = nlohmann::json::parse(message);
            // 如果是我发的
            if(msg_js["id"] == LocalUser::GetInstance().GetId())
            {
                int role = Chat_Role::ME;
                QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
            else
            {
                int role = Chat_Role::HE;
                QString user_name = ui->chat_people_name_label->text();
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
        }
        ui->list_wiget_stackedWidget->setCurrentIndex(USER_LIST_WIDGET);
    }
    else
    {
        auto history_message = MessageManager::GetInstance().getMessages(Mess_Type::GROUP_CHAT_TYPE, this->_userid);
        for(auto message : history_message)
        {
            nlohmann::json msg_js = nlohmann::json::parse(message);
            // 如果是我发的
            if(msg_js["id"] == LocalUser::GetInstance().GetId())
            {
                int role = Chat_Role::ME;
                QString user_name = QString::fromStdString(LocalUser::GetInstance().GetName());
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
            else
            {
                int role = Chat_Role::HE;
                QString user_name = QString::fromStdString(msg_js["name"]);
                QString user_icon_path = ":/mainwindow/pictures/people.png";

                ChatItem* p_chat_item = new ChatItem(role);
                p_chat_item->setUserName(user_name);
                p_chat_item->setUserIcon(QPixmap(user_icon_path));
                QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

                p_chat_item->setWidget(p_bubble);
                QListWidgetItem* p_item = new QListWidgetItem();

                p_item->setSizeHint(QSize(125,90));
                ui->message_show_listWidget->addItem(p_item);
                ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
            }
        }
        ui->list_wiget_stackedWidget->setCurrentIndex(GROUP_CHAT_LIST_WIDGET);
    }


    ui->chat_people_name_label->setText(chat_name);
    if(ui->stackedWidget->currentIndex() != 1)
        ui->stackedWidget->setCurrentIndex(1);

    // 把自己清空
    clear_left_list_widget(ui->search_listWidget);
}

void MainWindow::slot_new_message_add_item(std::string msg)
{
    nlohmann::json msg_js = nlohmann::json::parse(msg);
    int role = Chat_Role::HE;
    QString user_name;
    if(!msg_js.contains("groupid"))
    {
        user_name = ui->chat_people_name_label->text();
    }
    else
    {
        user_name = QString::fromStdString(msg_js["name"].get<std::string>());
    }

    QString user_icon_path = ":/mainwindow/pictures/people.png";

    ChatItem* p_chat_item = new ChatItem(role);
    p_chat_item->setUserName(user_name);
    p_chat_item->setUserIcon(QPixmap(user_icon_path));
    QWidget* p_bubble = new TextBubble(role,QString::fromStdString(msg_js["msg"].get<std::string>()));

    p_chat_item->setWidget(p_bubble);
    QListWidgetItem* p_item = new QListWidgetItem();

    p_item->setSizeHint(QSize(125,90));
    ui->message_show_listWidget->addItem(p_item);
    ui->message_show_listWidget->setItemWidget(p_item, p_chat_item);
}

/**
 * @brief MainWindow::slot_new_message_remind
 * 向消息栏中添加消息提醒
 * @param msg
 * 完整的json报文
 */
void MainWindow::slot_new_message_remind(std::string msg)
{
    CHAT_TYPE chat_type;
    unsigned int sender_id;
    nlohmann::json msg_js = nlohmann::json::parse(msg);
    if(!msg_js.contains("msgid"))
        return;

    // 分析消息类型是群聊还是单人聊天
    if(msg_js["msgid"] == 5)
    {
        chat_type = CHAT_TYPE::SINGLE_CHAT;
        sender_id = msg_js["id"];
    }
    else
    {
        chat_type = CHAT_TYPE::GROUP_CHAT;
        sender_id = msg_js["groupid"];
    }

    // 获取聊天消息内容和提醒者的名字，群聊就是群的名字，个人聊天就是那个人的名字
    QString sender_name;
    QString msg_content = QString::fromStdString(msg_js["msg"].get<std::string>());
    if((int)chat_type == (int)Mess_Type::ONE_CHAT_TYPE)
    {
        sender_name = QString::fromStdString(LocalUser::GetInstance().GetFriendName(sender_id));
    }
    else
    {
        sender_name = QString::fromStdString(LocalUser::GetInstance().GetGroupName(sender_id));
    }

    // 记录是否需要显示提醒红点
    int red_point_flag = true;
    if((int)this->_chat_type == chat_type && _userid == sender_id)
    {
        // 如果当前聊天对象就是消息提醒对象，则不显示红点
        red_point_flag = false;
    }

    QListWidgetItem* item_ptr = nullptr;
    QListWidgetItem* new_ptr = nullptr;
    for(auto it : _item_message_map)
    {
        // 如果消息列表中存在这个人的消息提示
        if((int)it.second.chat_type == chat_type && sender_id == it.second.id)
        {
            // 记录那条消息提示的item指针
            item_ptr = it.first;
            // 将那条消息item删除
            delete_list_widget_item(ui->message_listWidget, it.first);
            // 头插
            new_ptr = insert_left_list_widget_top_item(ui->message_listWidget, sender_name, msg_content, nullptr, chat_type, red_point_flag);
            break;
        }
    }

    // 如果不存在
    if(item_ptr == nullptr)
    {
        // 头插一个新的
        new_ptr = insert_left_list_widget_top_item(ui->message_listWidget, sender_name, msg_content, nullptr, chat_type, red_point_flag);
    }
    else
    {
        // 如果存在，头插后记得删除掉旧的
        _item_message_map.erase(item_ptr);
    }
    // 插入新的映射关系
    _item_message_map[new_ptr] = { chat_type, (unsigned int)sender_id};
}

void MainWindow::slot_search_lineedit_enter_press()
{
    QString search_name = ui->search_lineEdit->text();
    if(search_name.length() == 0)
        return;

    for(auto it : _item_userid_map)
    {
        QString name = QString::fromStdString(LocalUser::GetInstance().GetFriendName(it.second));
        if(search_name == name)
        {
            auto p_item = add_left_list_widget_item(ui->search_listWidget,name,"",nullptr,SINGLE_CHAT,false);
            _item_search_map[p_item] = {CHAT_TYPE::SINGLE_CHAT, (unsigned int)it.second};
        }
    }

    for(auto it : _item_groupid_map)
    {
        QString name = QString::fromStdString(LocalUser::GetInstance().GetGroupName(it.second));
        if(search_name == name)
        {
            auto p_item = add_left_list_widget_item(ui->search_listWidget,name,"",nullptr,SINGLE_CHAT,false);
            _item_search_map[p_item] = {CHAT_TYPE::SINGLE_CHAT,(unsigned int)it.second};
        }
    }

    ui->list_wiget_stackedWidget->setCurrentIndex(SEARCH_LIST_WIDGET);
}

void MainWindow::slot_add_menu_add_friend()
{
    if(_addwidget == nullptr)
    {
        _addwidget = new AddWidget(CHAT_TYPE::SINGLE_CHAT);
        connect(this->_addwidget,&AddWidget::signal_addwiget_close,this,&MainWindow::slot_addwidget_close);
        connect(this->_addwidget, &AddWidget::signal_added_user,this, &MainWindow::slot_added_user);
        connect(this->_addwidget, &AddWidget::signal_added_group,this, &MainWindow::slot_added_group);
        _addwidget->show();
    }
}

void MainWindow::slot_add_menu_add_group_chat()
{
    if(_addwidget == nullptr)
    {
        _addwidget = new AddWidget(CHAT_TYPE::GROUP_CHAT);
        connect(this->_addwidget,&AddWidget::signal_addwiget_close,this,&MainWindow::slot_addwidget_close);
        connect(this->_addwidget, &AddWidget::signal_added_user,this, &MainWindow::slot_added_user);
        connect(this->_addwidget, &AddWidget::signal_added_group,this, &MainWindow::slot_added_group);
        _addwidget->show();
    }
}

void MainWindow::slot_addwidget_close()
{
    if(_addwidget != nullptr)
    {
        qDebug() << "addwiget close" << Qt::endl;
        disconnect(this->_addwidget,&AddWidget::signal_addwiget_close,this,&MainWindow::slot_addwidget_close);
        disconnect(this->_addwidget, &AddWidget::signal_added_user,this, &MainWindow::slot_added_user);
        disconnect(this->_addwidget, &AddWidget::signal_added_group,this, &MainWindow::slot_added_group);
        delete _addwidget;
        _addwidget = nullptr;
    }
}

void MainWindow::slot_added_group()
{
    qDebug() << "add group suceess" << Qt::endl;
    clear_left_list_widget(ui->group_chat_listWidget);
    init_group_list();
}

void MainWindow::slot_added_user()
{
    qDebug() << "add user success" << Qt::endl;
    clear_left_list_widget(ui->user_list_listWidget);
    init_friends_list();
}

void MainWindow::slot_create_group()
{
    if(_create_group_widget == nullptr)
    {
        _create_group_widget = new CreateGroupWidget();
        connect(this->_create_group_widget,&CreateGroupWidget::signal_widget_close,this,&MainWindow::slot_create_group_widget_close);
        _create_group_widget->show();
    }
}

void MainWindow::slot_create_group_widget_close()
{
    if(_create_group_widget != nullptr)
    {
        disconnect(this->_create_group_widget,&CreateGroupWidget::signal_widget_close,this,&MainWindow::slot_create_group_widget_close);
        _create_group_widget->hide();
        delete _create_group_widget;
        clear_left_list_widget(ui->group_chat_listWidget);
        init_group_list();
    }
}

/**
 * @brief MainWindow::continued_listen_message
 * 消息持续监听。开启一个线程，持续监听从服务器发来的消息,并对报文进行解析，在主窗口上响应相应的动作
 */
void MainWindow::continued_listen_message()
{
    std::thread listen_thread = std::thread([&](){
        qDebug() << "listening thread start!" << Qt::endl;
        while(_is_listening.load())
        {
            // 接收来自服务器的消息
            std::string message = QChatSocket::GetInstance().Recv();
            // 如果消息为空
            if(message.empty())
                continue;

            qDebug() << message << Qt::endl;
            // 解析消息
            nlohmann::json msg_js = nlohmann::json::parse(message);
            if(msg_js["msgid"] == 5 || msg_js["msgid"] == 9)
            {
                // 如果是聊天消息
                int sender_id = -1;
                Mess_Type mess_type = Mess_Type::ONE_CHAT_TYPE;
                if(msg_js["msgid"] == ONE_CHAT_MSG)
                {
                    // 如果消息类型是单人聊天消息
                    sender_id = msg_js["id"];
                    mess_type = Mess_Type::ONE_CHAT_TYPE;
                }
                else if(msg_js["msgid"] == GROUP_CHAT_MSG)
                {
                    // 如果消息是群聊消息
                    sender_id = msg_js["groupid"];
                    mess_type = Mess_Type::GROUP_CHAT_TYPE;
                }

                // 如果消息类型为没有定义的类型，则
                if(sender_id == -1)
                    continue;

                // 如果send_id符合我们当前聊天窗口
                if(sender_id == _userid && (int)mess_type == (int)_chat_type)
                {
                    emit signal_new_message_add_item(message);
                }

                MessageManager::GetInstance().addMessage(mess_type, sender_id, message);

                emit signal_new_message_remind(message);
            }
            else if(msg_js["msgid"] == USER_ADDED_MSG)
            {
                qDebug() << "use be added as a friend" << Qt::endl;
                User user;
                user.SetId(msg_js["id"].get<unsigned int>());
                user.SetName(msg_js["name"].get<std::string>());
                auto friend_list = LocalUser::GetInstance().GetFriends();
                friend_list.emplace_back(user);
                LocalUser::GetInstance().SetFriends(friend_list);
                emit signal_added_refresh_user_list();
            }
        }

        qDebug() << "listening thread quit!" << Qt::endl;
    });

    listen_thread.detach();
}

QListWidgetItem* MainWindow::add_left_list_widget_item(QListWidget* target_widget ,const QString &chat_name, const QString &chat_message, QWidget *parent, int chat_type, bool flag)
{
    QListWidgetItem* p_item = new QListWidgetItem();
    p_item->setSizeHint(QSize(125,75));
    target_widget->addItem(p_item);

    CustemListItem* p_custem_item = new CustemListItem(chat_name, chat_message, parent, chat_type, flag);
    target_widget->setItemWidget(p_item,p_custem_item);

    return p_item;
}

QListWidgetItem *MainWindow::insert_left_list_widget_top_item(QListWidget *target_widget, const QString &chat_name, const QString &chat_message, QWidget *parent, int chat_type, bool flag)
{
    QListWidgetItem* p_item = new QListWidgetItem();
    p_item->setSizeHint(QSize(125,75));
    target_widget->insertItem(0, p_item);

    CustemListItem* p_custem_item = new CustemListItem(chat_name, chat_message, parent, chat_type, flag);
    target_widget->setItemWidget(p_item,p_custem_item);

    return p_item;
}

void MainWindow::delete_list_widget_item(QListWidget *target_widget, QListWidgetItem *target_item)
{
    if(target_item != nullptr && target_widget != nullptr)
    {
        // 获取widget
        QWidget* widget = target_widget->itemWidget(target_item);
        // 移除绑定
        target_widget->removeItemWidget(target_item);
        // 释放内存
        delete target_item;
        delete widget;
    }
}

void MainWindow::clear_left_list_widget(QListWidget *target_widget)
{
    if(target_widget != nullptr)
    {
        int count = target_widget->count();
        for(int i = 0; i < count; i++)
        {
            QListWidgetItem* item = target_widget->item(0);
            delete_list_widget_item(target_widget, item);
        }

        if(target_widget == ui->user_list_listWidget)
        {
            _item_userid_map.clear();
        }
        else if(target_widget == ui->group_chat_listWidget)
        {
            _item_groupid_map.clear();
        }
    }
}

void MainWindow::clear_right_list_widget()
{
    int count = ui->message_show_listWidget->count();
    for(int i = 0 ; i < count; i++)
    {
        QListWidgetItem* item = ui->message_show_listWidget->item(0);
        delete_list_widget_item(ui->message_show_listWidget, item);
    }
}
