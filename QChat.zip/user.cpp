#include "user.h"


void User::SetId(unsigned int id)
{
    this->_user_id = id;
}

void User::SetName(const std::string &name)
{
    this->_user_name = name;
}

void User::SetState(const std::string &state)
{
    this->_state = state;
}

unsigned int User::GetId()
{
    return this->_user_id;
}

std::string User::GetName()
{
    return this->_user_name;
}

std::string User::GetState()
{
    return this->_state;
}

void User::Reset()
{
    this->_user_id = 0;
    this->_user_name = "";
    this->_state = "offline";
}

User::User() : _user_id(0), _user_name(""), _state("offline")
{

}

