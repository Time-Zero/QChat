#ifndef USERINFOEDIT_H
#define USERINFOEDIT_H

#include <QWidget>

namespace Ui {
class UserInfoEdit;
}

class UserInfoEdit : public QWidget
{
    Q_OBJECT

public:
    explicit UserInfoEdit(QWidget *parent = nullptr);
    ~UserInfoEdit();

    // 设置用户id
    void SetId(unsigned int id);
    // 设置用户名
    void SetName(std::string name);

protected:
    void paintEvent(QPaintEvent *event);

private:
    Ui::UserInfoEdit *ui;
};

#endif // USERINFOEDIT_H
