#include "localuser.h"

LocalUser &LocalUser::GetInstance()
{
    static LocalUser instance;
    return instance;
}

void LocalUser::SetId(unsigned int id)
{
    _local_user.SetId(id);
}

void LocalUser::SetName(std::string name)
{
    _local_user.SetName(name);
}

void LocalUser::SetPwd(std::string pwd)
{
    this->_pwd = pwd;
}

void LocalUser::SetFriends(std::vector<User> friends)
{
    this->_friends.assign(friends.begin(),friends.end());
}

void LocalUser::SetOfflineMsg(std::vector<std::string> offlinemsg)
{
    this->_offlinemsg = offlinemsg;
}

void LocalUser::SetGroups(std::vector<Group> groups)
{
    this->_groups.assign(groups.begin(),groups.end());
}

unsigned int LocalUser::GetId()
{
    return this->_local_user.GetId();
}

std::string LocalUser::GetName()
{
    return this->_local_user.GetName();
}

std::string LocalUser::GetPwd()
{
    return this->_pwd;
}

std::vector<User> LocalUser::GetFriends()
{
    return this->_friends;
}

std::string LocalUser::GetFriendName(unsigned int id)
{
    for(auto it : this->_friends)
    {
        if(it.GetId() == id)
        {
            return it.GetName();
        }
    }

    return "";
}

std::vector<Group> LocalUser::GetGroups()
{
    return this->_groups;
}

std::string LocalUser::GetGroupName(unsigned int id)
{
    for(auto it : this->_groups)
    {
        if(it.GetId() == id)
            return it.GetName();
    }

    return "";
}

std::vector<std::string> &LocalUser::GetOfflineMsg()
{
    return this->_offlinemsg;
}

void LocalUser::Reset()
{
    this->_local_user.Reset();
    _friends.clear();
    _pwd.clear();
    _offlinemsg.clear();
}

LocalUser::LocalUser()
{

}
