#ifndef CUSTEMLISTITEM_H
#define CUSTEMLISTITEM_H

#include <QWidget>

enum CHAT_TYPE{
    SINGLE_CHAT = 0,
    GROUP_CHAT = 1,
};

namespace Ui {
class CustemListItem;
}

class CustemListItem : public QWidget
{
    Q_OBJECT

public:
    explicit CustemListItem(const QString& chat_name, const QString& chat_message, QWidget *parent = nullptr, int chat_type = SINGLE_CHAT, bool flag = true);
    ~CustemListItem();
    void set_chat_message(const QString& chat_message);
    void show_red_point(bool flag = true);

private:
    void init_chat_icon(int chat_type);
    void init_chat_title(const QString& chat_name, const QString& chat_message);
    void init_red_point(bool flag = true);

private:
    Ui::CustemListItem *ui;
};

#endif // CUSTEMLISTITEM_H
