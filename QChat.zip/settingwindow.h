#ifndef SETTINGWINDOW_H
#define SETTINGWINDOW_H

#include <QWidget>

namespace Ui {
class SettingWindow;
}

class SettingWindow : public QWidget
{
    Q_OBJECT

public:
    explicit SettingWindow(QWidget *parent = nullptr);
    ~SettingWindow();

signals:
    void LoginOut();        // 登出
    void EditUserInfo();    // 修改用户信息

protected:
    void paintEvent(QPaintEvent* event) override;


private:
    Ui::SettingWindow *ui;
};

#endif // SETTINGWINDOW_H
