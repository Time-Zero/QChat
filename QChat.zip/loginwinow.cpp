#include "loginwinow.h"
#include "ui_loginwinow.h"
#include <QLineEdit>
#include <QString>
#include "json.hpp"
#include <QIntValidator>
#include "public.h"
#include "qchatsocket.h"
#include "user.h"
#include <sstream>
#include "localuser.h"
#include <QFile>
#include <QMovie>
#include <QTextCodec>

LoginWinow::LoginWinow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::LoginWinow)
{
    ui->setupUi(this);

    // 引入qss文件美化
    QFile file(":/login/login.qss");
    if(file.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream qfilestream(&file);
        QString style_str = qfilestream.readAll();
        this->setStyleSheet(style_str);
        file.close();
    }

    this->setWindowTitle("QChat");
    this->setFixedSize(320,448);

    ui->gif_label->setFixedSize(45,45);
    QMovie* gif = new QMovie();
    gif->setFileName(":/login/pictures/rainbow_cat.gif");
    QSize si(ui->gif_label->width(),ui->gif_label->height());
    gif->setScaledSize(si);

    ui->gif_label->setMovie(gif);
    gif->start();

    // 设置启动初始窗口
    ui->stackedWidget->setCurrentIndex(0);

    // 设置userid栏只接收数字
    ui->userid_lineEdit->setValidator(new QIntValidator(ui->userid_lineEdit));

    // pwd栏只接收数字+英文+._
    ui->pwd_lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z0-9._]*")));
    ui->reg_pwd_lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z0-9._]*")));
    ui->reg_pwd_confirm_lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z0-9._]*")));

    ui->userid_lineEdit->setPlaceholderText("请输入11位账号");
    ui->pwd_lineEdit->setPlaceholderText("请输入密码");
    ui->reg_name_lineEdit->setPlaceholderText("请输入姓名");
    ui->reg_pwd_lineEdit->setPlaceholderText("请输入密码");
    ui->reg_pwd_confirm_lineEdit->setPlaceholderText("请确认密码");

    // 设置输入框为密码格式
    ui->pwd_lineEdit->setEchoMode(QLineEdit::Password);
    ui->reg_pwd_lineEdit->setEchoMode(QLineEdit::Password);
    ui->reg_pwd_confirm_lineEdit->setEchoMode(QLineEdit::Password);

    // 设置可以输入的最大长度
    ui->pwd_lineEdit->setMaxLength(50);
    ui->reg_name_lineEdit->setMaxLength(50);
    ui->reg_pwd_lineEdit->setMaxLength(50);
    ui->reg_pwd_confirm_lineEdit->setMaxLength(50);

    // 绑定功能键
    connect(ui->login_pushButton,&QPushButton::clicked,this,&LoginWinow::Login);
    // 处理注册事务
    connect(ui->reg_confirm_pushButton,&QPushButton::clicked,this, &LoginWinow::Reg);

    // 进去注册窗口
    connect(ui->reg_pushButton,&QPushButton::clicked,this,[&](){
        ui->stackedWidget->setCurrentIndex(1);
    });

    // 取消注册，返回登录窗口
    connect(ui->reg_cancal_pushButton, &QPushButton::clicked,this,[&](){
        ui->stackedWidget->setCurrentIndex(0);
        ui->reg_label->clear();
        ui->reg_name_lineEdit->clear();
        ui->reg_pwd_confirm_lineEdit->clear();
        ui->reg_pwd_lineEdit->clear();
    });


#ifdef DEBUG_VAR
    ui->userid_lineEdit->setText("00000000009");
    ui->pwd_lineEdit->setText("123456");
#endif

    this->show();
}

LoginWinow::~LoginWinow()
{
    delete ui;
}

void LoginWinow::Login()
{
    QString user_id = ui->userid_lineEdit->text();
    QString pwd = ui->pwd_lineEdit->text();

    if(user_id.length() < 11)
    {
        ui->login_msg_Label->setText("账号格式错误，请重新输入");
        return ;
    }

    if(pwd.length() == 0)
    {
        ui->login_msg_Label->setText("密码不能为空");
        return ;
    }

    // 封装登录报文
    nlohmann::json js;
    js["msgid"] = LOGIN_MSG;
    js["id"] = user_id.toUInt();
    js["password"] = pwd.toStdString();

    // 发送登录报文
    try
    {
        QChatSocket::GetInstance().Send(js.dump());
    }
    catch(const char* s)
    {
        ui->login_msg_Label->setText(s);
        return;
    }

    // 接收响应报文
    auto recv = QChatSocket::GetInstance().Recv();

    nlohmann::json ack_js = nlohmann::json::parse(recv);
    int err_no = ack_js["errno"].get<int>();
    if(err_no != 0)
    {
        // 登录出错
        std::string err_msg = ack_js["errmsg"].get<std::string>();
        ui->login_msg_Label->setText(err_msg.c_str());
        return;
    }

    LocalUser::GetInstance().SetId(ack_js["id"].get<unsigned int>());
    LocalUser::GetInstance().SetName(ack_js["name"].get<std::string>());
    LocalUser::GetInstance().SetPwd(pwd.toStdString());

    // 如果有离线消息
    if(ack_js.contains("offlinemsg"))
    {
        LocalUser::GetInstance().SetOfflineMsg(ack_js["offlinemsg"].get<std::vector<std::string>>());
    }

    // 如果有好友
    if(ack_js.contains("friends"))
    {
        std::vector<User> friends;
        std::vector<std::string> str_friends_vec = ack_js["friends"];
        for(auto str_friend : str_friends_vec)
        {
            nlohmann::json temp_js = nlohmann::json::parse(str_friend);;

            User user;
            user.SetId(temp_js["id"].get<unsigned int>());
            user.SetName(temp_js["name"].get<std::string>());
            user.SetState(temp_js["state"].get<std::string>());

            friends.emplace_back(user);
        }
        LocalUser::GetInstance().SetFriends(friends);
    }

    if(ack_js.contains("groups"))
    {
        std::vector<Group> groups;
        std::vector<std::string> str_groups_vec = ack_js["groups"];
        for(auto str_group : str_groups_vec)
        {
            nlohmann::json temp_js = nlohmann::json::parse(str_group);

            Group group;
            group.SetId(temp_js["id"].get<unsigned int>());
            group.SetName(temp_js["name"].get<std::string>());
            group.SetDesc(temp_js["desc"].get<std::string>());

            groups.emplace_back(group);
        }
        LocalUser::GetInstance().SetGroups(groups);
    }

    emit signal_login();
    this->hide();
}

void LoginWinow::Reg()
{
    QString user_name = ui->reg_name_lineEdit->text();
    QString pwd = ui->reg_pwd_lineEdit->text();
    QString pwd_confirm = ui->reg_pwd_confirm_lineEdit->text();

    if(user_name.length() < 1){
        ui->reg_label->setText("用户名格式错误");
        ui->reg_name_lineEdit->setFocus();
        return;
    }

    if(pwd.length() == 0)
    {
        ui->reg_label->setText("密码不能为空");
        ui->reg_pwd_lineEdit->setFocus();
        return;
    }

    if(pwd.length() < 6)
    {
        ui->reg_label->setText("密码长度过短");
        ui->reg_pwd_lineEdit->setFocus();
        return;
    }

    if(pwd != pwd_confirm)
    {
        ui->reg_label->setText("两次输入的密码不一致");
        ui->reg_pwd_confirm_lineEdit->setFocus();
        return;
    }

    nlohmann::json js;
    js["msgid"] = REG_MSG;
    js["name"] = user_name.toUtf8();
    js["password"] = pwd.toUtf8();

    try
    {
        // 发送注册信息
        QChatSocket::GetInstance().Send(js.dump());
    }
    catch(const char* s)
    {
        ui->reg_label->setText(s);
        return;
    }

    // 接收并解析响应，并且要关闭原来的socket
    std::string str_recv = QChatSocket::GetInstance().Recv();
    QChatSocket::GetInstance().Close();
    nlohmann::json recv_js = nlohmann::json::parse(str_recv);
    if(recv_js["errno"] != 0)
    {
        ui->reg_label->setText(recv_js["errmsg"].get<std::string>().c_str());
        return;
    }

    // 获取id并且将其补全为11位
    unsigned int user_id = recv_js["id"].get<unsigned int>();
    std::stringstream ss;
    ss << std::setw(11) << std::setfill('0') << user_id;

    // 合成提示信息
    char buf[128];
    memset(buf,0,sizeof(buf));
    sprintf(buf,"注册成功，你的账号是:%s",ss.str().c_str());
    ui->reg_label->setText(buf);
    ui->reg_cancal_pushButton->setText("返回登录");

    // 将得到的账号填充到登录窗口
    ui->userid_lineEdit->setText(ss.str().c_str());
}

