#ifndef BUBBLEFRAME_H
#define BUBBLEFRAME_H

#include <QFrame>
#include <QHBoxLayout>

enum Chat_Role
{
    ME = 0,
    HE = 1,
};

class BubbleFrame : public  QFrame
{
    Q_OBJECT
public:
    BubbleFrame(int role, QWidget* parent = nullptr);
    void setMargin(int margin);
    void setWidget(QWidget* w);

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    QHBoxLayout* _p_hlayout;
    int _role;
    int _margin;
};

#endif // BUBBLEFRAME_H
