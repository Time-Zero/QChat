#ifndef TEXTBUBBLE_H
#define TEXTBUBBLE_H

#include "bubbleframe.h"
#include <QTextEdit>
#include <QHBoxLayout>

class TextBubble : public BubbleFrame
{
public:
    TextBubble(int role, const QString& text, QWidget* parent = nullptr);

protected:
    bool eventFilter(QObject* object, QEvent* event) override;

private:
    void adjustTextHeiht();
    void setPlainText(const QString& text);
    void initStyleSheet();
private:
    QTextEdit* _pTextEdit;
};

#endif // TEXTBUBBLE_H
