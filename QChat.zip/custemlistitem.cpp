#include "custemlistitem.h"
#include "ui_custemlistitem.h"

CustemListItem::CustemListItem(const QString& chat_name, const QString& chat_message, QWidget *parent, int chat_type, bool flag)
    : QWidget(parent)
    , ui(new Ui::CustemListItem)
{
    ui->setupUi(this);
    init_chat_icon(chat_type);
    init_chat_title(chat_name, chat_message);
    init_red_point(flag);
}

CustemListItem::~CustemListItem()
{
    delete ui;
}

/**
 * @brief CustemListItem::set_chat_message
 * 设置消息概览内容
 * @param chat_message
 * 要设置的消息
 */
void CustemListItem::set_chat_message(const QString &chat_message)
{
    ui->chat_message_label->setText(chat_message);
}

/**
 * @brief CustemListItem::show_red_point
 * 控制新消息提示红点的显示
 * @param flag
 * 是否显示
 */
void CustemListItem::show_red_point(bool flag)
{
    ui->red_point_label->setVisible(flag);
}

/**
 * @brief CustemListItem::init_chat_icon
 * 初始化消息列表的icon
 * @param chat_type
 */
void CustemListItem::init_chat_icon(int chat_type)
{
    int fix_size = 40;
    ui->icon_label->setFixedSize(fix_size,fix_size);
    ui->icon_widget->setFixedSize(fix_size,fix_size);
    ui->icon_label->setStyleSheet("QLabel {padding: 4px;}");

    QString icon_path = "";
    if(chat_type == SINGLE_CHAT)
    {
        icon_path = ":/mainwindow/pictures/signal_chat.png";
    }
    else
    {
        icon_path = ":/mainwindow/pictures/group_chat.png";
    }

    QIcon icon = QIcon(icon_path);
    QPixmap pixmap = icon.pixmap(QSize(34,34));
    ui->icon_label->setPixmap(pixmap);
}

/**
 * @brief CustemListItem::init_chat_title
 * 初始化消息列表的消息发出者和消息内容概览
 * @param chat_name
 * 消息发出者
 * @param chat_message
 * 消息内容概览
 */
void CustemListItem::init_chat_title(const QString &chat_name, const QString &chat_message)
{
    // 145 * 75
    // ui->chat_title_widget->setFixedSize(145,75);

    QFont chat_name_font("Microsoft YaHei",11);
    ui->chat_name_label->setStyleSheet("color: black;");
    ui->chat_name_label->setFont(chat_name_font);
    ui->chat_name_label->setText(chat_name);

    QFont chat_message_font("Microsoft YaHei",10);
    ui->chat_message_label->setStyleSheet("color: gray;");
    ui->chat_message_label->setFont(chat_message_font);
    ui->chat_message_label->setText(chat_message);
}

/**
 * @brief CustemListItem::init_red_point
 * 初始化红点icon
 * @param flag
 * 是否显示红点
 */
void CustemListItem::init_red_point(bool flag)
{
    ui->red_point_widget->setMaximumWidth(30);
    QIcon icon = QIcon(":/mainwindow/pictures/red_point.png");
    QPixmap pixmap = icon.pixmap(QSize(30,30));
    ui->red_point_label->setPixmap(pixmap);
    show_red_point(flag);
}
