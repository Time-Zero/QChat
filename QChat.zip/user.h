#ifndef USER_H
#define USER_H

#include <string>
class User
{
public:

    void SetId(unsigned int id);

    void SetName(const std::string& name);

    void SetState(const std::string& state);

    unsigned int GetId();

    std::string GetName();

    std::string GetState();

    void Reset();

    User();

private:
    unsigned int _user_id;
    std::string _user_name;
    std::string _state;
};

#endif // USER_H
