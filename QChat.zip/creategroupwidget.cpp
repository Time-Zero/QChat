#include "creategroupwidget.h"
#include "ui_creategroupwidget.h"
#include <QFile>
#include <QMessageBox>
#include "json.hpp"
#include "public.h"
#include "localuser.h"
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <sstream>


CreateGroupWidget::CreateGroupWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::CreateGroupWidget)
{
    ui->setupUi(this);
    QFile file(":/login/login.qss");
    this->setWindowFlags(this->windowFlags() | Qt::WindowStaysOnTopHint);
    this->setWindowTitle("创建群聊");
    if(file.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream qfilestream(&file);
        QString style_str = qfilestream.readAll();
        this->setStyleSheet(style_str);
        file.close();
    }

    ui->name_lineEdit->setPlaceholderText("请输入群名称");
    ui->desc_lineEdit->setPlaceholderText("请输入群简介");
    ui->name_lineEdit->setMaxLength(50);
    ui->desc_lineEdit->setMaxLength(50);

    connect(ui->confirm_pushButton,&QPushButton::clicked,this, &CreateGroupWidget::slot_confirm_pushbutton_clicked);
    connect(ui->cancal_pushButton,&QPushButton::clicked,this,&CreateGroupWidget::slot_cancal_pushbutton_clicked);
}

CreateGroupWidget::~CreateGroupWidget()
{
    delete ui;
}

void CreateGroupWidget::closeEvent(QCloseEvent *event)
{
    emit signal_widget_close();
}

void CreateGroupWidget::slot_confirm_pushbutton_clicked()
{
    QString name = ui->name_lineEdit->text();
    if(name.length() == 0)
    {
        QMessageBox::information(this, "提示","群名称不允许为空");
        return;
    }

    QString desc = ui->desc_lineEdit->text();
    nlohmann::json js;
    js["msgid"] = CREAT_GROUP_MSG;
    js["id"] = LocalUser::GetInstance().GetId();
    js["groupname"] = name.toStdString();
    js["groupdesc"] = desc.toStdString();

    // 建立socket
    SOCKET conn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(conn == INVALID_SOCKET)
    {
        QMessageBox::information(this,"错误","和服务器建立通讯失败");
        return;
    }

    sockaddr_in client_service;
    client_service.sin_family = AF_INET;
    client_service.sin_port = htons(6000);
    client_service.sin_addr.S_un.S_addr = inet_addr("172.18.66.77");

    int iResult = WSAAPI::connect(conn, (SOCKADDR*)&client_service, sizeof(client_service));
    if(iResult == SOCKET_ERROR)
    {
        QMessageBox::information(this,"错误","和服务器建立通讯失败");
        closesocket(conn);
        return;
    }

    std::string str_js = js.dump();
    iResult = WSAAPI::send(conn,str_js.c_str(),str_js.size(),0);
    char recv_buf[1024];
    memset(recv_buf,0,sizeof(recv_buf));
    iResult = WSAAPI::recv(conn,recv_buf,sizeof(recv_buf),0);
    closesocket(conn);

    nlohmann::json ack_js = nlohmann::json::parse(recv_buf);
    unsigned int group_id = ack_js["id"].get<unsigned int>();
    Group group;
    group.SetId(group_id);
    group.SetName(name.toStdString());
    group.SetDesc(desc.toStdString());
    auto group_list = LocalUser::GetInstance().GetGroups();
    group_list.emplace_back(group);
    LocalUser::GetInstance().SetGroups(group_list);

    std::stringstream ss;
    ss << "创建群聊成功，id为" << std::setw(11) << std::setfill('0') << group_id;
    QMessageBox::information(this,"提示",QString::fromStdString(ss.str()));
}

void CreateGroupWidget::slot_cancal_pushbutton_clicked()
{
    emit signal_widget_close();
}
