#include "bubbleframe.h"

#include <QPainter>

const int WIDTH_TRIANGLE = 8;       // 三角形的宽

BubbleFrame::BubbleFrame(int role, QWidget *parent)
    : QFrame(parent),
    _p_hlayout(nullptr),
    _role(role),
    _margin(3)
{
    _p_hlayout = new QHBoxLayout();
    if(_role == Chat_Role::ME)
    {
        _p_hlayout->setContentsMargins(_margin, _margin, WIDTH_TRIANGLE + _margin, _margin);
    }
    else
    {
        _p_hlayout->setContentsMargins(WIDTH_TRIANGLE + _margin, _margin, _margin, _margin);
    }

    this->setLayout(_p_hlayout);
}

void BubbleFrame::setMargin(int margin)
{
    Q_UNUSED(_margin);
}

void BubbleFrame::setWidget(QWidget *w)
{
    if(_p_hlayout->count() > 0)
    {
        return;
    }
    else
    {
        _p_hlayout->addWidget(w);
    }
}

void BubbleFrame::paintEvent(QPaintEvent *event)
{

    QPainter painter(this);
    painter.setPen(Qt::NoPen);

    if(_role == Chat_Role::HE)
    {
        // 画气泡
        QColor bk_color(Qt::white);
        painter.setBrush(QBrush(bk_color));
        QRect bk_rect = QRect(WIDTH_TRIANGLE, 0, this->width() - WIDTH_TRIANGLE, this->height());
        painter.drawRoundedRect(bk_rect, 5,5);

        // 画小三角
        QPointF points[3] = {
            QPointF(bk_rect.x(), 12),
            QPointF(bk_rect.x(), 10 + WIDTH_TRIANGLE + 2),
            QPointF(bk_rect.x() - WIDTH_TRIANGLE, 10 + WIDTH_TRIANGLE - WIDTH_TRIANGLE / 2)
        };
        painter.drawPolygon(points,3);
    }
    else
    {
        QColor bk_color(158,234,106);
        painter.setBrush(QBrush(bk_color));
        //画气泡
        QRect bk_rect = QRect(0, 0, this->width()-WIDTH_TRIANGLE, this->height());
        painter.drawRoundedRect(bk_rect,5,5);
        //画三角
        QPointF points[3] = {
            QPointF(bk_rect.x()+bk_rect.width(), 12),
            QPointF(bk_rect.x()+bk_rect.width(), 12 + WIDTH_TRIANGLE +2),
            QPointF(bk_rect.x()+bk_rect.width() + WIDTH_TRIANGLE, 10 + WIDTH_TRIANGLE - WIDTH_TRIANGLE / 2),
        };
        painter.drawPolygon(points, 3);
    }

    return QFrame::paintEvent(event);
}
