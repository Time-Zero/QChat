#ifndef QCHATSOCKET_H
#define QCHATSOCKET_H

#include <WinSock2.h>
#include <WS2tcpip.h>
#include <string>
#include <atomic>

#pragma comment(lib, "ws2_32.lib")

class QChatSocket
{
public:
    QChatSocket(const QChatSocket&) = delete;
    ~QChatSocket();

    // 单例获取唯一实例
    static QChatSocket& GetInstance();

    // 发送报文
    int Send(const std::string& str);

    // 接收报文
    std::string Recv();

    // 关闭连接
    void Close();

private:
    QChatSocket();

private:
    SOCKET _conn;                               // 连接socket
    std::atomic_bool _is_close;                 // socket是否有效标志
};

#endif // QCHATSOCKET_H
