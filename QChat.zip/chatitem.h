#ifndef CHATITEM_H
#define CHATITEM_H

#include <QWidget>
#include "bubbleframe.h"
#include <QLabel>

class ChatItem : public QWidget
{
    Q_OBJECT
public:
    explicit ChatItem(int role, QWidget *parent = nullptr);
    void setUserName(const QString& name);
    void setUserIcon(const QPixmap& icon);
    void setWidget(QWidget* w);

signals:

private:
    int _role;
    QLabel* _pNameLabel;
    QLabel* _pIconLabel;
    QWidget* _pBubble;
};

#endif // CHATITEM_H
