#ifndef ADDWIDGET_H
#define ADDWIDGET_H

#include <QWidget>

namespace Ui {
class AddWidget;
}

class AddWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AddWidget(int add_type, QWidget *parent = nullptr);
    ~AddWidget();

signals:
    void signal_addwiget_close();

    void signal_added_group();
    void signal_added_user();

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void slot_search_lineedit_enter_press();

    void slot_add_pushbutton_clicked();

private:
    Ui::AddWidget *ui;
    int _add_type;
};

#endif // ADDWIDGET_H
