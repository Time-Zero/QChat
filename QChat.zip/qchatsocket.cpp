#include "qchatsocket.h"
#include <QDebug>

#define SERVER_PORT 8000

QChatSocket &QChatSocket::GetInstance()
{
    static QChatSocket instance;
    return instance;
}

int QChatSocket::Send(const std::string &str)
{
    // 如果因为登出而关闭连接，则重新建立连接
    if(_is_close.load())
    {
        int iResult = 0;
        this->_conn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if(this->_conn == INVALID_SOCKET)
        {
            WSACleanup();
            throw "Windows网络服务初始化失败";
        }

        sockaddr_in client_service;
        client_service.sin_family = AF_INET;
        client_service.sin_port = htons(SERVER_PORT);
        client_service.sin_addr.S_un.S_addr = inet_addr("172.18.66.77");

        // 尝试连接到服务器
        iResult = connect(this->_conn, (SOCKADDR*)&client_service, sizeof(client_service));
        if(iResult == SOCKET_ERROR)
        {
            qDebug() << "connect server failed!" << Qt::endl;
            closesocket(this->_conn);
            WSACleanup();
            throw "连接到服务器失败";
        }
        _is_close.store(false);
    }

    int iResult = send(this->_conn, str.c_str(), (int)str.size(), 0);
    return iResult;
}

std::string QChatSocket::Recv()
{
    char recv_buf[1024];
    memset(recv_buf,0,sizeof(recv_buf));
    int result = 0;

    // 带有阻塞的循环，等待可读事件的发生
    while(1)
    {
        // 如果关闭了连接，则退出
        if(_is_close.load())
        {
            return "";
        }

        // 设置超时时间为100ms
        timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 100;

        // 初始化fd_set
        fd_set fs;
        FD_ZERO(&fs);

        // 将本地连接加入fd_set
        FD_SET(this->_conn, &fs);

        // 监听可读事件
        result = select(NULL,&fs,nullptr,nullptr,&tv);

        // 如果出现了读事件或者socket在其他地方被关闭，则退出循环
        if(result == SOCKET_ERROR || FD_ISSET(this->_conn, &fs))
        {
            break;
        }

        // qDebug() << "recving" << Qt::endl;
    }

    // 如果socket在其他地方被关闭
    if(result == SOCKET_ERROR)
    {
        return "";
    }

    // 可读事件发生后，读取数据
    int iResult = recv(this->_conn, recv_buf, sizeof(recv_buf), 0);
    if(iResult > 0)
    {
        return std::string(recv_buf);
    }
    else
    {
        return std::string();
    }
}

void QChatSocket::Close()
{
    closesocket(this->_conn);
    _is_close.store(true);
}

QChatSocket::QChatSocket() : _is_close(true)
{
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if(iResult != NO_ERROR)
    {
        throw "Windows网络服务初始化失败";
    }

    this->_conn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(this->_conn == INVALID_SOCKET)
    {
        WSACleanup();
        throw "Windows网络服务初始化失败";
    }

    sockaddr_in client_service;
    client_service.sin_family = AF_INET;
    client_service.sin_port = htons(SERVER_PORT);
    client_service.sin_addr.S_un.S_addr = inet_addr("172.18.66.77");

    // 尝试连接到服务器
    iResult = connect(this->_conn, (SOCKADDR*)&client_service, sizeof(client_service));
    if(iResult == SOCKET_ERROR)
    {
        qDebug() << "connect server failed!" << Qt::endl;
        closesocket(this->_conn);
        WSACleanup();
        throw "连接到服务器失败";
    }

    _is_close.store(false);

    qDebug() << "connect server success!" << Qt::endl;
}

QChatSocket::~QChatSocket()
{
    int iResult = closesocket(this->_conn);
    if(iResult == SOCKET_ERROR)
    {
        WSACleanup();
        exit(EXIT_FAILURE);
    }
    WSACleanup();
}
