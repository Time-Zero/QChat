#include "addwidget.h"
#include "ui_addwidget.h"
#include "custemlistitem.h"
#include <QMessageBox>
#include "localuser.h"
#include <WinSock2.h>
#include <WS2tcpip.h>
#include "json.hpp"
#include "public.h"
#include <QValidator>
#include <QFile>

AddWidget::AddWidget(int add_type, QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::AddWidget)
    , _add_type(add_type)
{
    ui->setupUi(this);
    this->setWindowTitle("添加");
    this->setWindowFlags(Qt::WindowStaysOnTopHint);

    QFile file(":/login/login.qss");
    if(file.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream qfilestream(&file);
        QString style_str = qfilestream.readAll();
        this->setStyleSheet(style_str);
        file.close();
    }

    QString search_lineedit_takeplacetext;
    if(add_type == CHAT_TYPE::SINGLE_CHAT)
        search_lineedit_takeplacetext = "请输入用户11位id";
    else
        search_lineedit_takeplacetext = "请输入群11位id";

    ui->search_lineEdit->setPlaceholderText(search_lineedit_takeplacetext);
    ui->search_lineEdit->setValidator(new QIntValidator(ui->search_lineEdit));
    ui->search_lineEdit->setMaxLength(11);

    ui->res_widget->hide();

#ifdef DEBUG_VAR
    ui->search_lineEdit->setText("00000000002");
#endif

    connect(ui->search_lineEdit, &QLineEdit::returnPressed,this,&AddWidget::slot_search_lineedit_enter_press);
    connect(ui->add_pushButton, &QPushButton::clicked,this,&AddWidget::slot_add_pushbutton_clicked);
}

AddWidget::~AddWidget()
{
    delete ui;
}

void AddWidget::closeEvent(QCloseEvent *event)
{
    emit signal_addwiget_close();
}

void AddWidget::slot_search_lineedit_enter_press()
{
    QString id = ui->search_lineEdit->text();
    // 判断账号是否符合要求
    if(id.length() == 0)
    {
        QMessageBox::information(this,"错误","id不能为空");
        return;
    }
    else if(id.length() < 11)
    {
        QMessageBox::information(this,"错误","id格式错误");
        return;
    }

    unsigned int u_id = id.toUInt();
    // 判断要添加的对象是否已经加入了
    if(this->_add_type == CHAT_TYPE::SINGLE_CHAT)
    {
        if(u_id == LocalUser::GetInstance().GetId())
        {
            QMessageBox::information(this,"错误","你不能添加自己为好友");
            return;
        }

        for(auto it : LocalUser::GetInstance().GetFriends())
        {
            if(it.GetId() == u_id)
            {
                QMessageBox::information(this,"错误","你已经有了该好友");
                return;
            }
        }
    }
    else if (this->_add_type == CHAT_TYPE::GROUP_CHAT) {
        for(auto it : LocalUser::GetInstance().GetGroups())
        {
            if(it.GetId() == u_id)
            {
                QMessageBox::information(this,"错误","你已经加入该群聊");
                return;
            }
        }
    }

    // 建立socket
    SOCKET conn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(conn == INVALID_SOCKET)
    {
        QMessageBox::information(this,"错误","和服务器建立通讯失败");
        return;
    }

    sockaddr_in client_service;
    client_service.sin_family = AF_INET;
    client_service.sin_port = htons(6000);
    client_service.sin_addr.S_un.S_addr = inet_addr("172.18.66.77");

    int iResult = WSAAPI::connect(conn, (SOCKADDR*)&client_service, sizeof(client_service));
    if(iResult == SOCKET_ERROR)
    {
        QMessageBox::information(this,"错误","和服务器建立通讯失败");
        closesocket(conn);
        return;
    }

    if(this->_add_type == CHAT_TYPE::GROUP_CHAT)
    {
        nlohmann::json js;
        js["msgid"] = GROUP_SEARCH_MSG;
        js["id"] = u_id;

        std::string str_js = js.dump();
        iResult = WSAAPI::send(conn,str_js.c_str(),str_js.size(),0);

        char recv_buf[1024];
        memset(recv_buf,0,sizeof(recv_buf));
        iResult = WSAAPI::recv(conn,recv_buf,sizeof(recv_buf),0);
        closesocket(conn);

        nlohmann::json ack_js = nlohmann::json::parse(recv_buf);
        std::string name = ack_js["name"].get<std::string>();
        std::string desc = ack_js["desc"].get<std::string>();

        if(name.empty() && desc.empty())
        {
            QMessageBox::information(this,"提示","没有该id的群聊");
            return;
        }

        ui->name_label->setText(QString::fromStdString(name));
        ui->desc_label->setText(QString::fromStdString(desc));
    }
    else
    {
        nlohmann::json js;
        js["msgid"] = USER_SEARCH_MSG;
        js["id"] = u_id;

        std::string str_js = js.dump();
        iResult = WSAAPI::send(conn,str_js.c_str(),str_js.size(),0);

        char recv_buf[1024];
        memset(recv_buf,0,sizeof(recv_buf));
        iResult = WSAAPI::recv(conn,recv_buf,sizeof(recv_buf),0);
        closesocket(conn);

        nlohmann::json ack_js = nlohmann::json::parse(recv_buf);
        std::string name = ack_js["name"].get<std::string>();

        if(name.empty())
        {
            QMessageBox::information(this,"提示","没有该用户");
            return;
        }

        ui->name_label->setText(QString::fromStdString(name));
        ui->desc_label->hide();
    }

    ui->res_widget->show();
}

void AddWidget::slot_add_pushbutton_clicked()
{
    nlohmann::json js;
    QString user_id = ui->search_lineEdit->text();
    unsigned int u_id = user_id.toUInt();
    if(this->_add_type == CHAT_TYPE::SINGLE_CHAT)
    {
        js["msgid"] = ADD_FRIEND_MSG;
        js["id"] = LocalUser::GetInstance().GetId();
        js["friendid"] = u_id;

        User user;
        user.SetId(u_id);
        user.SetName(ui->name_label->text().toStdString());
        auto friend_list = LocalUser::GetInstance().GetFriends();
        friend_list.emplace_back(user);
        LocalUser::GetInstance().SetFriends(friend_list);
    }
    else
    {
        js["msgid"] = ADD_GROUP_MSG;
        js["id"] = LocalUser::GetInstance().GetId();
        js["groupid"] = u_id;

        Group group;
        group.SetId(u_id);
        group.SetName(ui->name_label->text().toStdString());
        group.SetDesc(ui->desc_label->text().toStdString());
        auto group_list = LocalUser::GetInstance().GetGroups();
        group_list.emplace_back(group);
        LocalUser::GetInstance().SetGroups(group_list);
    }

    // 建立socket
    SOCKET conn = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(conn == INVALID_SOCKET)
    {
        QMessageBox::information(this,"错误","和服务器建立通讯失败");
        return;
    }

    sockaddr_in client_service;
    client_service.sin_family = AF_INET;
    client_service.sin_port = htons(6000);
    client_service.sin_addr.S_un.S_addr = inet_addr("172.18.66.77");

    int iResult = WSAAPI::connect(conn, (SOCKADDR*)&client_service, sizeof(client_service));
    if(iResult == SOCKET_ERROR)
    {
        QMessageBox::information(this,"错误","和服务器建立通讯失败");
        closesocket(conn);
        return;
    }

    std::string str_js = js.dump();
    iResult = WSAAPI::send(conn,str_js.c_str(),str_js.size(),0);
    closesocket(conn);

    if(this->_add_type == CHAT_TYPE::SINGLE_CHAT)
    {
        emit signal_added_user();
    }
    else
    {
        emit signal_added_group();
    }

    QMessageBox::information(this,"提示","添加成功");
    this->close();
}


