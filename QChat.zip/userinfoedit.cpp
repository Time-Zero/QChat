#include "userinfoedit.h"
#include "ui_userinfoedit.h"
#include <QPainter>
#include <QFile>
#include <sstream>
#include <QRegularExpressionValidator>
#include "localuser.h"
#include "json.hpp"
#include "public.h"
#include "qchatsocket.h"

UserInfoEdit::UserInfoEdit(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::UserInfoEdit)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::SubWindow | Qt::WindowStaysOnTopHint);

    QFile file(":/userinfoedit/userinfoedit.qss");
    if(file.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream qfilestream(&file);
        QString style_str = qfilestream.readAll();
        this->setStyleSheet(style_str);
        file.close();
    }

    // 20%透明度
    this->setAttribute(Qt::WA_TranslucentBackground);
    this->setWindowOpacity(0.8);

    // 对lineedit的输入最大长度和输入内容做出限制
    ui->name_lineEdit->setMaxLength(50);
    ui->pwd_lineEdit->setMaxLength(50);
    ui->cf_pwd_lineEdit->setMaxLength(50);

    ui->pwd_lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z0-9._]*")));
    ui->cf_pwd_lineEdit->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Za-z0-9._]*")));

    // 设置窗口阻塞
    this->setWindowModality(Qt::ApplicationModal);

    // 设置窗口设置固定大小
    this->setFixedSize(250,400);

    ui->pwd_lineEdit->setEchoMode(QLineEdit::Password);
    ui->cf_pwd_lineEdit->setEchoMode(QLineEdit::Password);
    ui->id_lineEdit->setDisabled(true);

    connect(ui->cancal_pushButton, &QPushButton::clicked,this,[&](){
        // 设置窗口隐藏
        this->hide();

        // 设置窗口内容清空
        ui->id_lineEdit->clear();
        ui->name_lineEdit->clear();
        ui->pwd_lineEdit->clear();
        ui->cf_pwd_lineEdit->clear();
        ui->remaind_label->clear();
    });

    connect(ui->ok_pushButton,&QPushButton::clicked,this,[&](){
        // std::string name = ui->name_lineEdit->text().toUtf8();
        QString name = ui->name_lineEdit->text();
        QString pwd = ui->pwd_lineEdit->text();
        QString cf_pwd = ui->cf_pwd_lineEdit->text();


        if(name.isEmpty())
        {
            ui->remaind_label->setText("用户名不能为空");
            return;
        }

        if(pwd != cf_pwd)
        {
            ui->remaind_label->setText("两次输入的密码不一致");
            return;
        }

        // 如果密码为空，则获取原来的密码
        if(pwd.isEmpty())
        {
            pwd = QString::fromStdString(LocalUser::GetInstance().GetPwd());
        }

        nlohmann::json js;
        js["msgid"] = USER_INFO_EDIT_MSG;
        js["id"] = LocalUser::GetInstance().GetId();
        js["name"] = name.toUtf8();
        js["password"] = pwd.toUtf8();

        // 发送修改报文
        QChatSocket::GetInstance().Send(js.dump());
        // 修改本地保存的信息
        LocalUser::GetInstance().SetName(name.toStdString());
        if(!pwd.isEmpty())
        {
            LocalUser::GetInstance().SetPwd(pwd.toStdString());
        }

        ui->remaind_label->setText("修改成功");
        this->hide();

        ui->remaind_label->clear();
        ui->name_lineEdit->clear();
        ui->pwd_lineEdit->clear();
        ui->cf_pwd_lineEdit->clear();
    });

    this->hide();
}

UserInfoEdit::~UserInfoEdit()
{
    delete ui;
}

void UserInfoEdit::SetId(unsigned int id)
{
    std::stringstream ss;
    ss << std::setw(11) << std::setfill('0') << id;

    ui->id_lineEdit->setText(ss.str().c_str());
}

void UserInfoEdit::SetName(std::string name)
{
    ui->name_lineEdit->setText(name.c_str());
}

void UserInfoEdit::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setBrush(QBrush(Qt::white));

    painter.setPen(Qt::transparent);

    QRect rect = this->rect();
    rect.setWidth(rect.width() - 1);
    rect.setHeight(rect.height() - 1);
    painter.drawRoundedRect(rect,15,15);

}
