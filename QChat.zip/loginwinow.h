#ifndef LOGINWINOW_H
#define LOGINWINOW_H

#include <QWidget>
#include <QPushButton>

namespace Ui {
class LoginWinow;
}

class LoginWinow : public QWidget
{
    Q_OBJECT

public:
    explicit LoginWinow(QWidget *parent = nullptr);
    ~LoginWinow();

    void Login();

    void Reg();

signals:
    void signal_login();

private:
    Ui::LoginWinow *ui;
};

#endif // LOGINWINOW_H
