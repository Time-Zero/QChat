#include "group.h"

Group::Group() {}

void Group::SetId(unsigned int id)
{
    this->_id = id;
}

void Group::SetName(const std::string &name)
{
    this->_name = name;
}

void Group::SetDesc(const std::string &desc)
{
    this->_desc = desc;
}

void Group::SetUsers(const std::vector<User> &users)
{
    this->_users = users;
}

unsigned int Group::GetId()
{
    return this->_id;
}

std::string Group::GetName()
{
    return this->_name;
}

std::string Group::GetDesc()
{
    return this->_desc;
}

std::vector<User> Group::GetUsers()
{
    return this->_users;
}
