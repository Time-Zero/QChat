#ifndef CREATEGROUPWIDGET_H
#define CREATEGROUPWIDGET_H

#include <QWidget>

namespace Ui {
class CreateGroupWidget;
}

class CreateGroupWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CreateGroupWidget(QWidget *parent = nullptr);
    ~CreateGroupWidget();

signals:
    void signal_widget_close();

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void slot_confirm_pushbutton_clicked();
    void slot_cancal_pushbutton_clicked();

private:
    Ui::CreateGroupWidget *ui;
};

#endif // CREATEGROUPWIDGET_H
