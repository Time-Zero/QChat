#ifndef LOCALUSER_H
#define LOCALUSER_H

#include <vector>
#include "user.h"
#include <string>
#include "group.h"

class LocalUser
{
public:
    LocalUser(const LocalUser&) = delete;
    static LocalUser& GetInstance();

    // 设置id
    void SetId(unsigned int id);

    // 设置name
    void SetName(std::string name);

    // 设置pwd
    void SetPwd(std::string pwd);

    // 设置好友列表
    void SetFriends(std::vector<User> friends);

    // 设置离线消息
    void SetOfflineMsg(std::vector<std::string> offlinemsg);

    void SetGroups(std::vector<Group> groups);

    // 获取id
    unsigned int GetId();

    // 获取姓名
    std::string GetName();

    // 获取密码
    std::string GetPwd();

    // 获取好友列表
    std::vector<User> GetFriends();

    std::string GetFriendName(unsigned int id);

    std::vector<Group> GetGroups();

    std::string GetGroupName(unsigned int id);

    // 获取离线消息
    std::vector<std::string>& GetOfflineMsg();

    // 登出后重置本地状态
    void Reset();

private:
    LocalUser();

private:
    User _local_user;
    std::vector<User> _friends;
    std::string _pwd;
    std::vector<std::string> _offlinemsg;
    std::vector<Group> _groups;
};

#endif // LOCALUSER_H
