#ifndef GROUP_H
#define GROUP_H

#include <string>
#include "user.h"
#include <vector>

class Group
{
public:
    Group();
    void SetId(unsigned int id);
    void SetName(const std::string& name);
    void SetDesc(const std::string& desc);
    void SetUsers(const std::vector<User>& users);
    unsigned int GetId();
    std::string GetName();
    std::string GetDesc();
    std::vector<User> GetUsers();


private:
    unsigned int _id;
    std::string _name;
    std::string _desc;
    std::vector<User> _users;
};

#endif // GROUP_H
