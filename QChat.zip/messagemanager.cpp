#include "messagemanager.h"
#include <fstream>
#include <sstream>
#include "localuser.h"
#include <QDebug>

MessageManager::MessageManager()
    : _user_mess_file(nullptr),
    _group_mess_file(nullptr)
{

}

MessageManager &MessageManager::GetInstance()
{
    static MessageManager instance;
    return instance;
}

MessageManager::~MessageManager()
{
    this->clear();
}

void MessageManager::addMessage(Mess_Type type ,unsigned int id, const std::string& message)
{
    if(type == Mess_Type::ONE_CHAT_TYPE)
    {
        auto it = _user_mess_map.find(id);
        if(it == _user_mess_map.end())
        {
            _user_mess_map[id] = std::vector<std::string>();
        }

        _user_mess_map[id].emplace_back(message);
        _user_mess_json[std::to_string(id)] = _user_mess_map[id];
        if(_user_mess_file != nullptr && _user_mess_file->is_open())
        {
            _user_mess_file->seekp(0);
            *_user_mess_file << _user_mess_json.dump();
            _user_mess_file->flush();
        }
    }
    else
    {
        auto it = _group_mess_map.find(id);
        if(it == _group_mess_map.end())
        {
            _group_mess_map[id] = std::vector<std::string>();
        }
        _group_mess_map[id].emplace_back(message);
        _group_mess_json[std::to_string(id)] = _group_mess_map[id];
        if(_group_mess_file != nullptr && _group_mess_file->is_open())
        {
            _group_mess_file->seekp(0);
            *_group_mess_file << _group_mess_json.dump();
            _group_mess_file->flush();
        }
    }
}

std::vector<std::string> MessageManager::getMessages(Mess_Type type, unsigned int id)
{
    if(type == Mess_Type::ONE_CHAT_TYPE)
    {
        auto it = _user_mess_map.find(id);
        if(it == _user_mess_map.end())
        {
            return {};
        }

        return it->second;
    }
    else
    {
        auto it = _group_mess_map.find(id);
        if(it == _group_mess_map.end())
        {
            return {};
        }
        return it->second;
    }
}

/**
 * @brief MessageManager::load
 * 用于加载当前用户的聊天记录，登录之后必须执行load操作
 */
void MessageManager::load()
{
    if(_user_mess_file != nullptr || _group_mess_file != nullptr)
        return;

    std::string user_mess_file_path;
    std::string group_mess_file_path;
    int current_user_id = LocalUser::GetInstance().GetId();
    std::stringstream ss;
    ss << ".\\" << current_user_id << "_one_chat.json";
    user_mess_file_path = ss.str();
    ss.str("");
    ss << ".\\" << current_user_id << "_group_chat.json";
    group_mess_file_path = ss.str();

    // 先以读取模式打开文件，如果能打开，就说明这个用户存在可以恢复的聊天数据
    _user_mess_file = new std::fstream(user_mess_file_path, std::ios::in);
    if(_user_mess_file->is_open())
    {
        // qDebug() << user_mess_file_path << " open succeess!" << Qt::endl;
        std::stringstream user_mess;
        *_user_mess_file >> user_mess.rdbuf();
        if(!user_mess.str().empty())
        {
           _user_mess_json = nlohmann::json::parse(user_mess.str());
            for(auto& it : _user_mess_json.items())
            {
                _user_mess_map[std::stoi(it.key())] = it.value().get<std::vector<std::string>>();
            }
        }
    }

    _group_mess_file = new std::fstream(group_mess_file_path, std::ios::in);
    if(_group_mess_file->is_open())
    {
        // qDebug() << group_mess_file_path << " open success!" << Qt::endl;
        std::stringstream group_mess;
        *_group_mess_file >> group_mess.rdbuf();
        if(!group_mess.str().empty())
        {
            _group_mess_json = nlohmann::json::parse(group_mess.str());
            for(auto& it : _group_mess_json.items())
            {
                _group_mess_map[std::stoi(it.key())] = it.value().get<std::vector<std::string>>();
            }
        }
    }

    // 修改文件描述符模式，修改为写入模式并且设置为覆盖写
    _user_mess_file->close();
    _user_mess_file->open(user_mess_file_path, std::ios::out);
    if(_user_mess_file->is_open())
    {
        qDebug() << user_mess_file_path << " ready!" << Qt::endl;
    }
    _group_mess_file->close();
    _group_mess_file->open(group_mess_file_path, std::ios::out);
    if(_group_mess_file->is_open())
    {
        qDebug() << group_mess_file_path << " ready!" << Qt::endl;
    }
}

/**
 * @brief MessageManager::clear
 *  清除保存用户聊天数据的所有结构，用于退出登录和切换登录用户
 */
void MessageManager::clear()
{
    // 关闭文件指针
    if(_user_mess_file != nullptr && _user_mess_file->is_open())
    {
        _user_mess_file->seekp(0);
        *_user_mess_file << _user_mess_json.dump();
        _user_mess_file->close();
        delete _user_mess_file;
        _user_mess_file = nullptr;
    }

    if(_group_mess_file != nullptr && _group_mess_file->is_open())
    {
        _group_mess_file->seekp(0);
        *_group_mess_file << _group_mess_json.dump();
        _group_mess_file->close();
        delete _group_mess_file;
        _group_mess_file = nullptr;
    }

    // 清除map和json
    _user_mess_map.clear();
    _group_mess_map.clear();
    _user_mess_json.clear();
    _group_mess_map.clear();
}
