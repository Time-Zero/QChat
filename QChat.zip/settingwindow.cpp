#include "settingwindow.h"
#include "ui_settingwindow.h"
#include <QPainter>
#include <QFile>

SettingWindow::SettingWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::SettingWindow)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::SubWindow | Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);

    // 设置背景透明
    this->setAttribute(Qt::WA_TranslucentBackground);
    this->setWindowOpacity(0.8);

    this->resize(175,255);
    hide();

    // 按下登出按钮，设置窗口隐藏并且发送登出信号到主窗口
    connect(ui->settting_login_out,&QPushButton::clicked,this,[&](){
        this->hide();
        emit LoginOut();
    });

    // 按下用户信息修改按钮，设置窗口隐藏并且发送用户信息修改信号到主窗口
    connect(ui->setting_account_edit,&QPushButton::clicked,this,[&](){
        this->hide();
        emit EditUserInfo();
    });
}

SettingWindow::~SettingWindow()
{
    delete ui;
}

void SettingWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setBrush(QBrush(Qt::white));

    // QPen pen;
    // pen.setColor(Qt::gray);
    // pen.setWidth(2);
    painter.setPen(Qt::transparent);

    QRect rect = this->rect();
    rect.setWidth(rect.width() - 1);
    rect.setHeight(rect.height() - 1);
    painter.drawRoundedRect(rect,15,15);

    // QPen pen;
    // pen.setColor(Qt::darkGray);
    // pen.setWidth(2);
    // painter.setPen(pen);
    // painter.drawRect(this->rect());
    // painter.end();
    // QWidget::paintEvent(event);
}

